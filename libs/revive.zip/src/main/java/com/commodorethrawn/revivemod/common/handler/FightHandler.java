package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.Random;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class FightHandler {
    private static Random rand = new Random();
    @SubscribeEvent
    public static void moveEvent(TickEvent.PlayerTickEvent event) {
        if (!event.player.world.isRemote && FightStartHandler.inFight && (event.player.getEntityData().hasKey("oldPos") || event.player.getEntityData().hasKey("isDead"))) {
            BlockPos pos = event.player.getPosition();
            if (pos.getDistance(ReviveConfig.bossX, ReviveConfig.bossY, ReviveConfig.bossZ) > 80 && rand.nextInt(10) == 0) {
                event.player.setPositionAndUpdate(ReviveConfig.bossX, ReviveConfig.bossY + 10, ReviveConfig.bossZ);
            }
        }
    }

    @SubscribeEvent
    public static void bossHurt(LivingHurtEvent event) {
        if (!event.getEntityLiving().world.isRemote && event.getEntityLiving().getEntityData().hasKey("isBoss")) {
            updateHealth(event.getEntityLiving(), -event.getAmount());
        }
    }
    @SubscribeEvent
    public static void bossHeal(LivingHealEvent event) {
        if (!event.getEntityLiving().world.isRemote && event.getEntityLiving().getEntityData().hasKey("isBoss")) {
            updateHealth(event.getEntityLiving(), event.getAmount());
        }
    }
    private static void updateHealth(EntityLivingBase boss, float modifier) {
        if (FightStartHandler.bossInfo != null) {
            float healthPercent = (boss.getHealth() + modifier) / boss.getMaxHealth();
            FightStartHandler.bossInfo.setPercent(healthPercent);
        }
    }
}
