package com.commodorethrawn.revivemod.common.storage;

import com.commodorethrawn.revivemod.ReviveMod;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class StorageHandler {
    private static Map<UUID, BlockPos> idToPosMap = new HashMap<>();
    private static Map<BlockPos, UUID> posToIdMap = new HashMap<>();
    private static Map<BlockPos, Boolean> postoEnabledMap = new HashMap<>();

    public static void addGrave(UUID playerId, BlockPos gravePos, boolean enabled) {
        idToPosMap.put(playerId, gravePos);
        posToIdMap.put(gravePos, playerId);
        postoEnabledMap.put(gravePos, enabled);
        if (ReviveMod.data != null) {
            ReviveMod.data.markDirty();
        }
    }

    public static void removeGrave(UUID playerId) {
        BlockPos pos = idToPosMap.get(playerId);
        try {
            FMLCommonHandler.instance().getMinecraftServerInstance().getEntityWorld().setBlockToAir(pos);
        } catch (NullPointerException ex) {}
        idToPosMap.remove(playerId);
        posToIdMap.remove(pos);
        postoEnabledMap.remove(pos);
        ReviveMod.data.markDirty();
    }

    public static void removeGrave(BlockPos pos) {
        UUID id = posToIdMap.get(pos);
        posToIdMap.remove(pos);
        idToPosMap.remove(id);
        postoEnabledMap.remove(pos);
        FMLCommonHandler.instance().getMinecraftServerInstance().getEntityWorld().setBlockToAir(pos);
        ReviveMod.data.markDirty();
    }

    public static boolean isDead(UUID playerId) {
        return idToPosMap.containsKey(playerId);
    }

    // Note : requires block to be a sign
    // Returns null if not a grave
    public static UUID getGraveId(BlockPos pos) {
        return posToIdMap.get(pos);
    }

    // Returns null if no such grave
    public static BlockPos getGravePos(UUID playerId) {
        return idToPosMap.get(playerId);
    }

    public static Set<UUID> getGraveIds() {
        return idToPosMap.keySet();
    }

    public static boolean isGraveEnabled(BlockPos pos) {
        return postoEnabledMap.get(pos);
    }

    public static void disableGrave(BlockPos pos) {
        postoEnabledMap.put(pos, false);
    }

    public static void clearData() {
        idToPosMap.clear();
        posToIdMap.clear();
    }
}
