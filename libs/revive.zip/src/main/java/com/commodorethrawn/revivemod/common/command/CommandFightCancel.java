package com.commodorethrawn.revivemod.common.command;

import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import com.commodorethrawn.revivemod.common.handler.FightEndHandler;
import com.commodorethrawn.revivemod.common.handler.FightStartHandler;
import com.commodorethrawn.revivemod.common.util.CommonHelper;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.GameType;

import java.util.List;

public class CommandFightCancel extends CommandBase {
    @Override
    public String getName() {
        return "cancelfight";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "cancelfight";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        FightStartHandler.inFight = false;
        Class bossClass = EntityList.getClass(new ResourceLocation(ReviveConfig.bossMob));
        AxisAlignedBB arena = new AxisAlignedBB(ReviveConfig.bossX - 100, ReviveConfig.bossY - 100, ReviveConfig.bossZ - 100, ReviveConfig.bossX + 100, ReviveConfig.bossY + 100, ReviveConfig.bossZ + 100);
        List<Entity> entityList = server.getEntityWorld().getEntitiesWithinAABB(bossClass, arena);
        for (Entity entity : entityList) {
            if (entity.getEntityData().hasKey("isBoss")) {
                entity.getEntityData().removeTag("isBoss");
                entity.setDead();
                break;
            }
        }
        server.getPlayerList().sendMessage(new TextComponentTranslation("revivemod.fightcancel"));
        if (FightStartHandler.bossInfo != null) {
            FightStartHandler.bossInfo.setVisible(false);
            FightStartHandler.bossInfo = null;
        }
        List<EntityPlayerMP> playerList = server.getEntityWorld().getEntitiesWithinAABB(EntityPlayerMP.class, arena);
        for (EntityPlayerMP player : playerList) {
            player.sendMessage(new TextComponentTranslation("revivemod.returning"));
            BlockPos oldPos = NBTUtil.getPosFromTag(player.getEntityData().getCompoundTag("oldPos"));
            player.setPositionAndUpdate(oldPos.getX(), oldPos.getY(), oldPos.getZ());
            if (player.getEntityData().hasKey("isFighter")) {
                player.getEntityData().removeTag("isFighter");
                EntityPlayer teammate = player.getEntityWorld().getPlayerEntityByUUID(CommonHelper.getPair(player.getUniqueID()));
                if (teammate != null) {
                    teammate.setPositionAndUpdate(oldPos.getX(), oldPos.getY() + 2, oldPos.getZ());
                }
            } else {
                GameType oldType = GameType.getByID(player.getEntityData().getInteger("oldGamemode"));
                player.setGameType(oldType);
            }
            player.getEntityData().removeTag("oldPos");
            player.getEntityData().removeTag("oldGamemode");
        }
        FightEndHandler.buildArena();
    }
}
