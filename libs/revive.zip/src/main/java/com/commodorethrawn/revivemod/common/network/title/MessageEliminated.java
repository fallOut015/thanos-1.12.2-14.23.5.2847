package com.commodorethrawn.revivemod.common.network.title;

import com.daposeidonguy.teamsmod.common.storage.StorageHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.init.SoundEvents;
import net.minecraft.server.management.PlayerProfileCache;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

import java.util.List;
import java.util.UUID;

public class MessageEliminated extends AbstractMessageTitle {

    public MessageEliminated() {
    }

    public MessageEliminated(String teamName) {
        super("revivemod.teameliminated",
                "revivemod.subeliminated",
                0.5F,
                0.0F,
                0.0F,
                30,
                240,
                genArgs(teamName));
    }

    public static String[] genArgs(String teamName) {
        List<UUID> teamPlayers = StorageHelper.getTeamPlayers(teamName);
        PlayerProfileCache cache = FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerProfileCache();
        String player1 = cache.getProfileByUUID(teamPlayers.get(0)).getName();
        String player2 = cache.getProfileByUUID(teamPlayers.get(1)).getName();
        return new String[]{player1, player2};
    }

    public static class MessageHandler implements IMessageHandler<MessageEliminated, IMessage> {
        @Override
        public IMessage onMessage(MessageEliminated message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                Minecraft.getMinecraft().player.playSound(SoundEvents.ENTITY_ENDERDRAGON_DEATH, 1.0F, 1.0F);
            });
            return AbstractMessageTitle.onMessage(message);
        }
    }
}
