package com.commodorethrawn.revivemod.common.network;

import com.commodorethrawn.revivemod.client.ParticleAltar;
import com.commodorethrawn.revivemod.client.SatanStar;
import com.commodorethrawn.revivemod.common.handler.AltarHandler;
import com.commodorethrawn.revivemod.common.util.ActionScheduler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import static com.commodorethrawn.revivemod.client.SatanStar.*;

public class MessageAltar extends AbstractMessage {
    public MessageAltar() {
        super();
    }

    public MessageAltar(double x, double y, double z, boolean showing, boolean reviving) {
        tag.setDouble("x", x);
        tag.setDouble("y", y);
        tag.setDouble("z", z);
        tag.setBoolean("showing", showing);
        tag.setBoolean("reviving", reviving);
    }

    public static class MessageHandler implements IMessageHandler<MessageAltar, IMessage> {

        @Override
        public IMessage onMessage(MessageAltar message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                baseX = message.tag.getDouble("x") + 0.5D;
                baseY = message.tag.getDouble("y") - 1.95D;
                baseZ = message.tag.getDouble("z") + 0.5D;
                int tickDelay = 0;
                if (message.tag.getBoolean("showing") && !AltarHandler.showStar) {
                    tickDelay = firstDraw();
                }
                ActionScheduler.scheduleTask(tickDelay, () -> {
                    AltarHandler.showStar = message.tag.getBoolean("showing");
                    AltarHandler.isReviving = message.tag.getBoolean("reviving");
                });
            });
            return null;
        }

        @SideOnly(Side.CLIENT)
        public int firstDraw() {
            WorldClient world = Minecraft.getMinecraft().world;
            int tickDelay = 0;
            for (double angle = 0.0D; angle < twopi; angle += increment) {
                double x = baseX + Math.cos(angle) * radius;
                double z = baseZ + Math.sin(angle) * radius;
                ActionScheduler.scheduleTask(tickDelay, () -> {
                    ParticleAltar.addParticle(world, x, baseY, z, 0.0F, 0.0F, 0.0F);
                });
                tickDelay += 2;
            }
            double lineX = baseX - radius / 4D;
            drawLine(world, lineX, baseZ - radius, 0.0, 2.0D, tickDelay);
            drawLine(world, lineX, baseZ + radius, 1.14D, -1.643D, tickDelay);
            drawLine(world, baseX - radius, baseZ, 1.92D, -0.56D, tickDelay);
            drawLine(world, lineX, baseZ - radius , 1.14D, 1.643D, tickDelay);
            return drawLine(world, baseX - radius, baseZ, 1.92D, 0.56D, tickDelay);
        }

        @SideOnly(Side.CLIENT)
        public static int drawLine(WorldClient world, double startX, double startZ, double incrX, double incrZ, int delay) {
            int iter = 0;
            int tickDelay = delay;
            while (true) {
                double lineX = startX + iter * incrX * increment;
                double lineZ = startZ + iter * incrZ * increment;
                if (!inCircle(lineX, lineZ)) break;
                ActionScheduler.scheduleTask(tickDelay, () -> {
                    ParticleAltar.addParticle(world, lineX, baseY, lineZ, 0.0F, 0.0F, 0.0F);
                });
                tickDelay += 2;
                iter += 1;
            }
            return tickDelay;
        }
    }
}
