package com.commodorethrawn.revivemod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.ParticleFlame;
import net.minecraft.world.World;

public class ParticleAltar extends ParticleFlame {

    public static void addParticle(World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        Minecraft.getMinecraft().effectRenderer.addEffect(new ParticleAltar(world, x, y, z, xSpeed, ySpeed, zSpeed));
    }

    protected ParticleAltar(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
        super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
        particleMaxAge = 120;
    }


}
