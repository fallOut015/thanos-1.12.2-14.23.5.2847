package com.commodorethrawn.revivemod.common.network.title;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageCountdown extends AbstractMessageTitle {

    public MessageCountdown() {
        super();
    }

    public MessageCountdown(String titleKey, String subKey, float red, float green, float blue, int fadeTime, int time, String... args) {
        super(titleKey, subKey, red, green, blue, fadeTime, time, args);
    }

    public static class Handler implements IMessageHandler<MessageCountdown, IMessage> {

        @Override
        public IMessage onMessage(MessageCountdown message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {

            });
            return null;
        }
    }
}
