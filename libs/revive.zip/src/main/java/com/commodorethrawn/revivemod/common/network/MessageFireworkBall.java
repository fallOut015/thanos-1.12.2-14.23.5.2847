package com.commodorethrawn.revivemod.common.network;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageFireworkBall extends AbstractMessage {

    public MessageFireworkBall() {
        super();
    }

    public MessageFireworkBall(double x, double y, double z) {
        tag.setDouble("x", x);
        tag.setDouble("y", y);
        tag.setDouble("z", z);    }

    public static class MessageHandler implements IMessageHandler<MessageFireworkBall, IMessage> {

        @Override
        public IMessage onMessage(MessageFireworkBall message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                WorldClient world = FMLClientHandler.instance().getWorldClient();
                NBTTagCompound fireworkTag = new NBTTagCompound();
                fireworkTag.setInteger("Flight", 0);
                NBTTagList explosionsTag = new NBTTagList();
                NBTTagCompound explosionTag = new NBTTagCompound();
                NBTTagCompound explosion1Tag = new NBTTagCompound();
                explosionTag.setInteger("Type", 1);
                explosion1Tag.setInteger("Type", 4);
                explosionTag.setInteger("Flicker", 1);
                explosion1Tag.setInteger("Flicker", 1);
                explosionTag.setInteger("Trail", 1);
                explosion1Tag.setInteger("Trail", 1);
                int[] explosionColors = new int[]{1973019,4408131};
                int[] explosion1Colors = new int[]{4408131,11743532};
                explosionTag.setIntArray("Colors", explosionColors);
                explosionTag.setIntArray("FadeColors", explosion1Colors);
                explosion1Tag.setIntArray("Colors", explosion1Colors);
                explosion1Tag.setIntArray("FadeColors", explosionColors);
                explosionsTag.appendTag(explosionTag);
                explosionsTag.appendTag(explosion1Tag);
                fireworkTag.setTag("Explosions", explosionsTag);
                world.makeFireworks(message.tag.getDouble("x"),
                        message.tag.getDouble("y"),
                        message.tag.getDouble("z"),
                        0.0F, 0.5F, 0.0F,
                        fireworkTag);
            });
            return null;
        }
    }
}
