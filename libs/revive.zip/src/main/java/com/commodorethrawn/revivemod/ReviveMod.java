package com.commodorethrawn.revivemod;

import com.commodorethrawn.revivemod.common.command.CommandFightCancel;
import com.commodorethrawn.revivemod.common.command.CommandGrave;
import com.commodorethrawn.revivemod.common.command.CommandSpectate;
import com.commodorethrawn.revivemod.common.network.PacketHandler;
import com.commodorethrawn.revivemod.common.storage.SaveData;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(modid = ReviveMod.MODID, name = ReviveMod.MODNAME, version = ReviveMod.MODVERSION, acceptedMinecraftVersions = ReviveMod.MCVERSION, dependencies = ReviveMod.DEPENDENCIES)
public class ReviveMod {

    public static final String MODID = "revivemod";
    public static final String MODNAME = "Revive Mod";
    public static final String MODVERSION = "1.0";
    public static final String MCVERSION = "[1.12.2]";
    public static final String DEPENDENCIES = "required-after:worldedit;required-after:teamsmod";
    public static SaveData data;
    public static Logger logger = LogManager.getLogger(MODID);

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        PacketHandler.registerPackets(Side.SERVER);
        if (event.getSide() == Side.CLIENT) {
            PacketHandler.registerPackets(Side.CLIENT);
        }
    }

    @Mod.EventHandler
    public void serverStart(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandGrave());
        event.registerServerCommand(new CommandSpectate());
        event.registerServerCommand(new CommandFightCancel());
        data = SaveData.get(event.getServer().getEntityWorld());
    }

    @Mod.EventHandler
    public void serverStop(FMLServerStoppingEvent event) {
        data.markDirty();
    }

}
