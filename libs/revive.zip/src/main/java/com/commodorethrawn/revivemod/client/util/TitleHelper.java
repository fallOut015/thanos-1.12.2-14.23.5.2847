package com.commodorethrawn.revivemod.client.util;

import com.commodorethrawn.revivemod.ReviveMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID, value = Side.CLIENT)
public class TitleHelper {

    private static Queue<TitleObject> titleQueue = new LinkedBlockingQueue<>();

    private static int ticks = 0;
    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (!titleQueue.isEmpty()) {
            ++ticks;
        }
    }

    @SubscribeEvent
    public static void renderTick(TickEvent.RenderTickEvent event) {
        if (!titleQueue.isEmpty()) {
            TitleObject title = titleQueue.peek();
            if (title.getFirstDisplayTick() == -1) {
                title.setFirstDisplayTick(ticks);
            }
            if (Minecraft.getMinecraft().currentScreen != null) {
                return;
            }
            if (ticks < title.getDeathTick()) {
                if (ticks == title.getFirstDisplayTick()) {
                    return;
                }
                Minecraft mc = Minecraft.getMinecraft();
                ScaledResolution res = new ScaledResolution(mc);
                drawTitle(title, mc, res);
                if (ticks > title.getSubFirstDisplayTick() && ticks < title.getSubDeathTick()) {
                    drawSubtitle(title, mc, res);
                }
            } else {
                titleQueue.remove();
            }
        }
    }

    private static void drawTitle(TitleObject title, Minecraft mc, ScaledResolution res) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(res.getScaledWidth() / 2, res.getScaledHeight() / 2, 0.0F);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        float alphaTitle;
        if (ticks < title.getFadedInTick()) {
            alphaTitle = (ticks - title.getFirstDisplayTick()) * 1.0F / title.getFadeTicks();
        } else if (ticks < title.getFadedInTick() + title.getDisplayTicks()) {
            alphaTitle = 1.0F;
        } else {
            alphaTitle = (title.getDeathTick() - ticks) * 1.0F / title.getFadeTicks();
        }
        Color colorTitle = new Color(title.colorRed, title.colorGreen, title.colorBlue, alphaTitle);
        GlStateManager.scale(2.5F, 2.5F, 2.5F);
        mc.ingameGUI.getFontRenderer().drawString(title.getTitleText(), (float)-mc.fontRenderer.getStringWidth(title.getTitleText()) / 2, -5.0F, colorTitle.getRGB(), true);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawSubtitle(TitleObject title, Minecraft mc, ScaledResolution res) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(res.getScaledWidth() / 2, res.getScaledHeight() / 2 + 20.0F, 0.0F);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        float alphaSubtitle;
        if (ticks < title.getSubFadedInTick()) {
            alphaSubtitle = (ticks - title.getSubFirstDisplayTick()) * 1.0F / title.getFadeTicks();
        } else if (ticks < title.getSubFadedInTick() + title.getSubDisplayTicks()) {
            alphaSubtitle = 1.0F;
        } else {
            alphaSubtitle = (title.getSubDeathTick() - ticks) * 1.0F / title.getFadeTicks();
        }
        Color colorSubtitle = new Color(0.5F, 0.5F, 0.5F, alphaSubtitle);
        GlStateManager.scale(1.5F, 1.5F, 1.5F);
        mc.ingameGUI.getFontRenderer().drawString(title.getSubtitleText(), (float)-mc.fontRenderer.getStringWidth(title.getSubtitleText()) / 2, -5.0F, colorSubtitle.getRGB(), true);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void addTitle(String titleString, String subtitleString, float colorRed, float colorGreen, float colorBlue, int fade, int time) {
        TitleObject newTitle = new TitleObject(titleString, subtitleString, colorRed, colorGreen, colorBlue, fade, time);
        titleQueue.add(newTitle);
    }

    public static void clearTitles() {
        titleQueue.clear();
    }

    private static class TitleObject {

        private final int displayTime, fadeTime;
        private int firstDisplayTick;
        private final String titleText, subtitleText;
        float colorRed, colorGreen, colorBlue;

        TitleObject(String titleString, String subTitleString, float colorRed, float colorGreen, float colorBlue, int fadeTime, int time) {
            titleText = titleString;
            subtitleText = subTitleString;
            this.fadeTime = fadeTime;
            displayTime = time;
            this.colorRed = colorRed;
            this.colorBlue = colorBlue;
            this.colorGreen = colorGreen;
            firstDisplayTick = -1;
        }

        String getTitleText() {
            return titleText;
        }

        String getSubtitleText() {
            return subtitleText;
        }

        void setFirstDisplayTick(int tick) {
            firstDisplayTick = tick;
        }

        int getFirstDisplayTick() {
            return firstDisplayTick;
        }

        int getFadedInTick() {
            return getFirstDisplayTick() + fadeTime;
        }

        int getDeathTick() {
            return getFadedInTick() + displayTime + fadeTime;
        }

        int getFadeTicks() {
            return fadeTime;
        }

        int getDisplayTicks() {
            return displayTime;
        }

        int getSubFirstDisplayTick() {
            return firstDisplayTick + fadeTime;
        }

        int getSubFadedInTick() {
            return getSubFirstDisplayTick() + fadeTime;
        }

        int getSubDeathTick() {
            return getDeathTick() - fadeTime;
        }

        int getSubDisplayTicks() {
            return displayTime - 2 * fadeTime;
        }

    }
}
