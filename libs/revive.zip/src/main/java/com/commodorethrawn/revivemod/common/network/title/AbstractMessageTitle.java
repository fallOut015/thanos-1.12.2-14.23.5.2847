package com.commodorethrawn.revivemod.common.network.title;

import com.commodorethrawn.revivemod.client.util.TitleHelper;
import com.commodorethrawn.revivemod.common.network.AbstractMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public abstract class AbstractMessageTitle extends AbstractMessage {

    public AbstractMessageTitle() {
    }

    public AbstractMessageTitle(String titleKey, String subKey, float[] colors, int fadeTime, int time, String... args) {
        this(titleKey, subKey, colors[0], colors[1], colors[2], fadeTime, time, args);
    }

    public AbstractMessageTitle(String titleKey, String subKey, float red, float green, float blue, int fadeTime, int time, String... args) {
        NBTTagList argsTag = new NBTTagList();
        for (int i = 0; i < args.length; ++i) {
            argsTag.appendTag(new NBTTagString(args[i]));
        }
        tag.setTag("args", argsTag);
        tag.setString("subKey", subKey);
        tag.setString("titleKey", titleKey);
        tag.setFloat("red", red);
        tag.setFloat("green", green);
        tag.setFloat("blue", blue);
        tag.setInteger("fadeTime", fadeTime);
        tag.setInteger("time", time);
    }


    public static IMessage onMessage(AbstractMessageTitle message) {
        Minecraft.getMinecraft().addScheduledTask(() -> {
            String title = I18n.format(message.tag.getString("titleKey"));
            NBTTagList argsTag = message.tag.getTagList("args", Constants.NBT.TAG_STRING);
            String[] args = new String[argsTag.tagCount()];
            int index = 0;
            for (NBTBase tag : argsTag) {
                NBTTagString stringTag = (NBTTagString) tag;
                args[index] = stringTag.getString();
                ++index;
            }
            String subtitle = I18n.format(message.tag.getString("subKey"), args);
            TitleHelper.addTitle(title,
                    subtitle,
                    message.tag.getFloat("red"),
                    message.tag.getFloat("green"),
                    message.tag.getFloat("blue"),
                    message.tag.getInteger("fadeTime"),
                    message.tag.getInteger("time"));
        });
        return null;
    }

    public static class Basic extends AbstractMessageTitle {
        public Basic() {
        }

        public Basic(String titleKey, String subKey, float red, float green, float blue, int fadeTime, int time, String... args) {
            super(titleKey, subKey, red, green, blue, fadeTime, time, args);
        }

        public static class Handler implements IMessageHandler<Basic, IMessage> {
            @Override
            public IMessage onMessage(Basic message, MessageContext ctx) {
                Basic.onMessage(message);
                return null;
            }
        }
    }
}
