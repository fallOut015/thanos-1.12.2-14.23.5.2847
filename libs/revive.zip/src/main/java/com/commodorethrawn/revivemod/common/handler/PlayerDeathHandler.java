package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.network.title.AbstractMessageTitle;
import com.commodorethrawn.revivemod.common.network.PacketHandler;
import com.commodorethrawn.revivemod.common.storage.StorageHandler;
import com.commodorethrawn.revivemod.common.util.CommonHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.client.config.GuiConfigEntries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class PlayerDeathHandler {

    @SubscribeEvent
    public static void chat(ServerChatEvent event) {
        if (!event.getPlayer().world.isRemote && event.getPlayer().getEntityData().hasKey("isDead") && event.getPlayer().isSpectator()) {
            ITextComponent component = event.getComponent();
            TextComponentString prefixDead = new TextComponentString("[MUERTO] ");
            prefixDead.setStyle(new Style().setColor(TextFormatting.DARK_RED));
            prefixDead.appendSibling(component.setStyle(new Style().setColor(TextFormatting.WHITE)));
            event.setComponent(prefixDead);
        }
    }

    private static int millisPerDay = 1000 * 60 * 60 * 24;
    private static int millisPerHour = 1000 * 60 * 60;
    private static int millisPerMinute = 1000 * 60;
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void tooltip(ItemTooltipEvent event) {
        if (event.getItemStack().getItem() == Items.SKULL && event.getItemStack().getMetadata() == 3) {
            ItemStack skullStack = event.getItemStack();
            if (skullStack.hasTagCompound() && skullStack.getTagCompound().hasKey("player")) {
                String playerName = skullStack.getTagCompound().getString("player");
                long deathTime = skullStack.getTagCompound().getLong("deathTime");
                long timeSinceDeath = System.currentTimeMillis() - deathTime;
                int days = (int) (timeSinceDeath / millisPerDay);
                int hours = (int) ((timeSinceDeath - days * millisPerDay) / millisPerHour);
                int minutes = (int) (((timeSinceDeath - days * millisPerDay - hours * millisPerHour)) / millisPerMinute);
                event.getToolTip().add("Nombre: " + playerName);
                event.getToolTip().add("Tiempo sobrevivido:");
                event.getToolTip().add(days + ":" + hours + ":" + minutes);
            }
        }
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void onDeathScreen(GuiOpenEvent event) {
        if (event.getGui() instanceof GuiGameOver) {
            event.setCanceled(true);
            Minecraft.getMinecraft().player.respawnPlayer();
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDamageEvent event) {
        if (!event.getEntityLiving().world.isRemote
                && event.getEntityLiving() instanceof EntityPlayerMP
                && CommonHelper.isInPair(event.getEntity().getUniqueID())
                && event.getAmount() > event.getEntityLiving().getHealth()) {
            event.setCanceled(true);
            EntityPlayerMP playerMP = (EntityPlayerMP) event.getEntityLiving();
            UUID pairId = CommonHelper.getPair(playerMP.getUniqueID());
            if (!StorageHandler.isDead(pairId)) {
                PacketHandler.INSTANCE.sendToAll(new AbstractMessageTitle.Basic("revivemod.playerdeath", "revivemod.subdeath", 0.3F, 0.1F, 0.1F, 30, 240, playerMP.getName()));
            }
            playerMP.setGameType(GameType.SPECTATOR);
            playerMP.getEntityData().removeTag("oldPos");
            playerMP.getEntityData().removeTag("oldGamemode");
            playerMP.getEntityData().setBoolean("isDead", true);
            World world = event.getEntity().world;
            BlockPos deathPos = playerMP.getPosition();
            world.addWeatherEffect(new EntityLightningBolt(world, deathPos.getX(), deathPos.getY(), deathPos.getZ(), true));
            ItemStack skull = getSkull(playerMP);
            placeChest(world, deathPos);
            List<ItemStack> itemList = new ArrayList<>();
            for (int i = 0; i < playerMP.inventory.getSizeInventory(); ++i) {
                if (playerMP.inventory.getStackInSlot(i) != ItemStack.EMPTY) {
                    itemList.add(playerMP.inventory.getStackInSlot(i));
                }
            }
            fillChest(world, deathPos, itemList, skull);
            playerMP.inventory.clear();
            playerMP.setHealth(20.0F);
            playerMP.getFoodStats().setFoodLevel(20);
            MinecraftForge.EVENT_BUS.post(new LivingDeathEvent(event.getEntityLiving(), event.getSource()));
        }
    }

    private static void placeChest(World world, BlockPos chestPos) {
        world.setBlockState(chestPos, Blocks.CHEST.getDefaultState());
        if (world.getBlockState(chestPos.add(1, 0, 0)).getBlock() == Blocks.AIR) {
            world.setBlockState(chestPos.add(1, 0, 0), Blocks.CHEST.getDefaultState());
        } else if (world.getBlockState(chestPos.add(-1, 0, 0)).getBlock() == Blocks.AIR) {
            world.setBlockState(chestPos.add(-1, 0, 0), Blocks.CHEST.getDefaultState());
        } else if (world.getBlockState(chestPos.add(0, 0, 1)).getBlock() == Blocks.AIR) {
            world.setBlockState(chestPos.add(0, 0, 1), Blocks.CHEST.getDefaultState());
        } else {
            world.setBlockState(chestPos.add(0, 0, -1), Blocks.CHEST.getDefaultState());
        }
    }

    private static ItemStack getSkull(EntityPlayerMP playerMP) {
        ItemStack stackSkull = new ItemStack(Items.SKULL, 1, 3);
        NBTTagCompound compoundSkull = new NBTTagCompound();
        compoundSkull.setTag("SkullOwner", new NBTTagString(playerMP.getName()));
        compoundSkull.setString("player", playerMP.getName());
        compoundSkull.setLong("deathTime", System.currentTimeMillis());
        stackSkull.setTagCompound(compoundSkull);
        return stackSkull;
    }

    private static void fillChest(World world, BlockPos chestPos, List<ItemStack> drops, ItemStack skull) {
        IItemHandler chestInv = world.getTileEntity(chestPos).getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
        int chestIndex = 0;
        chestInv.insertItem(chestIndex, skull, false);
        for (ItemStack stack : drops) {
            chestInv.insertItem(++chestIndex, stack, false);
        }
    }

}
