package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import net.minecraft.entity.EntityCreature;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class ArenaHandler {

    @SubscribeEvent
    public static void mobSpawn(LivingSpawnEvent.CheckSpawn event) {
        if (!event.getWorld().isRemote
            && event.getEntity().getPosition().getDistance(ReviveConfig.bossX, ReviveConfig.bossY, ReviveConfig.bossZ) <= 90
            && event.getEntity() instanceof EntityCreature) {
            event.setResult(Event.Result.DENY);
        }
    }

}
