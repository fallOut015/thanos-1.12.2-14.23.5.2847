package com.commodorethrawn.revivemod.client;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.handler.AltarHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = ReviveMod.MODID, value = Side.CLIENT)
public class SatanStar {
    public static double baseX;
    public static double baseY;
    public static double baseZ;
    public static double radius = 2.0D;
    public static double twopi = 2 * Math.PI;
    public static double increment = 0.4D / Math.PI;

    private static int ticks = 20;
    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && Minecraft.getMinecraft().world != null) {
            ++ticks;
            WorldClient world = Minecraft.getMinecraft().world;
            if (AltarHandler.showStar) {
                if (AltarHandler.isReviving) {
                    if (ticks % 5 == 0) {
                        for (double angle = 0.0D; angle < twopi; angle += increment) {
                            double x = baseX + Math.cos(angle) * radius;
                            double z = baseZ + Math.sin(angle) * radius;
                            world.spawnParticle(EnumParticleTypes.FLAME, x, baseY, z, 0.0F, 0.15F, 0.0F);
                        }
                    }
                } else {
                    if (ticks % 10 == 0) {
                        for (double angle = 0.0D; angle < twopi; angle += increment) {
                            double x = baseX + Math.cos(angle) * radius;
                            double z = baseZ + Math.sin(angle) * radius;
                            world.spawnParticle(EnumParticleTypes.FLAME, x, baseY, z, 0.0F, 0.02F, 0.0F);
                        }
                    }
                }
                if (ticks % 10 == 0) {
                    drawStar(world);
                }
            } else {
                if (Minecraft.getMinecraft().player.getPosition().getDistance((int)baseX, (int)baseY, (int)baseZ) <= 5) {
                    if (ticks % 10 == 0) {
                        double startX = baseX - 1;
                        double startZ = baseZ - 1;
                        for (int x = 0; x < 3; ++x) {
                            for (int z = 0; z < 3; ++z) {
                                world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, startX + x, baseY, startZ + z, 0.0F, 0.03F, 0.0F);
                            }
                        }
                    }
                }
            }
        }
    }

    public static void drawStar(WorldClient world) {
        double lineX = baseX - radius / 4D;
        drawBisection(world, lineX, baseZ - radius, 0.0, 2.0D);
        drawBisection(world, lineX, baseZ - radius , 1.14D, 1.643D);
        drawBisection(world, lineX, baseZ + radius, 1.14D, -1.643D);
        drawBisection(world, baseX - radius, baseZ, 1.92D, -0.56D);
        drawBisection(world, baseX - radius, baseZ, 1.92D, 0.56D);
    }

    public static void drawBisection(WorldClient world, double startX, double startZ, double incrX, double incrZ) {
        double lineX = startX;
        double lineZ = startZ;
        while (inCircle(lineX, lineZ)) {
            world.spawnParticle(EnumParticleTypes.FLAME, lineX, baseY, lineZ, 0.0F, 0.02F, 0.0F);
            lineX += incrX * increment;
            lineZ += incrZ * increment;
        }
    }

    public static boolean inCircle(double x, double z) {
        double diffX = x - baseX;
        double diffZ = z - baseZ;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        return dist <= radius + increment;
    }
}
