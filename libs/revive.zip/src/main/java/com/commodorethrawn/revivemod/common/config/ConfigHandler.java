package com.commodorethrawn.revivemod.common.config;

import com.commodorethrawn.revivemod.ReviveMod;
import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class ConfigHandler {
    @SubscribeEvent
    public static void onConfigUpdate(ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equals(ReviveMod.MODID)) {
            ConfigManager.sync(ReviveMod.MODID, Config.Type.INSTANCE);
        }
    }
}
