package com.commodorethrawn.revivemod.common.network;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageLookDir extends AbstractMessage {
    public MessageLookDir() {

    }

    public MessageLookDir(float yaw, float pitch) {
        tag.setFloat("yaw", yaw);
        tag.setFloat("pitch", pitch);
    }

    public static class MessageHandler implements IMessageHandler<MessageLookDir, IMessage> {

        @Override
        public IMessage onMessage(MessageLookDir message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                Minecraft.getMinecraft().player.rotationYaw = message.tag.getFloat("yaw");
                Minecraft.getMinecraft().player.rotationPitch = message.tag.getFloat("pitch");
            });
            return null;
        }
    }
}
