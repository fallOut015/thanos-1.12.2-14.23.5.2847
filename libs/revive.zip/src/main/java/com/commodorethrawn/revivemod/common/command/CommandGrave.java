package com.commodorethrawn.revivemod.common.command;

import com.commodorethrawn.revivemod.common.storage.StorageHandler;
import com.mojang.authlib.GameProfile;
import net.minecraft.block.BlockWallSign;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.List;

public class CommandGrave extends CommandBase {

    @Override
    public String getName() {
        return "grave";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/grave <playerName> <line1> <line2>";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2) {
            throw new CommandException(new TextComponentTranslation("revivemod.badsyntax").getFormattedText());
        }
        String deadName = args[0];
        GameProfile profile = server.getPlayerProfileCache().getGameProfileForUsername(deadName);
        if (profile == null) {
            throw new CommandException(new TextComponentTranslation("revivemod.invalidplayer").getFormattedText());
        }
        if (!(sender instanceof EntityPlayerMP)) {
            throw new CommandException(new TextComponentTranslation("revivemod.notplayer").getFormattedText());
        }
        EntityPlayerMP senderPlayer = (EntityPlayerMP) sender;
        EnumFacing facing = senderPlayer.getHorizontalFacing();
        Vec3i directionVec = facing.getDirectionVec();
        BlockPos gravePos = senderPlayer.getPosition().add(directionVec).add(directionVec).add(0, 1, 0);
        if (server.getEntityWorld().getBlockState(gravePos.add(directionVec)) != Blocks.STONE.getStateFromMeta(6)) {
            throw new CommandException(new TextComponentTranslation("revivemod.notgrave").getFormattedText());
        }
        server.getEntityWorld().setBlockState(gravePos, Blocks.WALL_SIGN.getDefaultState().withProperty(BlockWallSign.FACING, facing.getOpposite()));
        TileEntitySign tileEntitySign = (TileEntitySign) server.getEntityWorld().getTileEntity(gravePos);
        tileEntitySign.signText[0] = new TextComponentString("RIP").setStyle(new Style().setBold(true));
        tileEntitySign.signText[1] = new TextComponentString(deadName);
        tileEntitySign.signText[2] = new TextComponentString(args[1]);
        if (args.length > 2) {
            tileEntitySign.signText[3] = new TextComponentString(args[2]);
        }
        List<EntityPlayerMP> players = server.getEntityWorld().getEntitiesWithinAABB(EntityPlayerMP.class, new AxisAlignedBB(tileEntitySign.getPos()).grow(50, 50, 50));
        for (EntityPlayerMP player : players) {
            player.connection.sendPacket(tileEntitySign.getUpdatePacket());
        }
        StorageHandler.addGrave(profile.getId(), gravePos, true);
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos) {
        if (args.length == 1) {
            return Arrays.asList(FMLCommonHandler.instance().getMinecraftServerInstance().getOnlinePlayerNames());
        } else {
            return super.getTabCompletions(server, sender, args, targetPos);
        }
    }
}
