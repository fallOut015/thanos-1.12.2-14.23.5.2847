package com.commodorethrawn.revivemod.common.command;

import com.commodorethrawn.revivemod.common.handler.FightStartHandler;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.GameType;

public class CommandSpectate extends CommandBase {

    @Override
    public String getName() {
        return "spectate";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/spectate";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
        return true;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayerMP)) {
            throw new CommandException(new TextComponentTranslation("revivemod.notplayer").getFormattedText());
        }
        if (!FightStartHandler.inFight) {
            throw new CommandException(new TextComponentTranslation("revivemod.nofight").getFormattedText());
        }
        EntityPlayerMP playerMP = (EntityPlayerMP) sender;
        if (playerMP.getEntityData().hasKey("isFighter")) {
            throw new CommandException(new TextComponentTranslation("revivemod.spectatingfighter").getFormattedText());
        }
        playerMP.getEntityData().setInteger("oldGamemode", playerMP.interactionManager.getGameType().getID());
        playerMP.getEntityData().setTag("oldPos", NBTUtil.createPosTag(sender.getPosition()));
        playerMP.setPositionAndUpdate(ReviveConfig.teleportX, ReviveConfig.teleportY + 10, ReviveConfig.teleportZ);
        playerMP.setGameType(GameType.SPECTATOR);
        FightStartHandler.addSpectator(playerMP);
    }
}
