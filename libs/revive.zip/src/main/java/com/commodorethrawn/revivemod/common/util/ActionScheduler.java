package com.commodorethrawn.revivemod.common.util;

import com.commodorethrawn.revivemod.ReviveMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.PriorityQueue;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class ActionScheduler {

    private static PriorityQueue<ActionEntry> actionQueue = new PriorityQueue<>();

    private static long ticks = 0;
    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && FMLCommonHandler.instance().getSide().isServer()) {
            while (!actionQueue.isEmpty() && ticks == actionQueue.peek().tick) {
                actionQueue.remove().execute();
            }
            ++ticks;
        }
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END
            && Minecraft.getMinecraft().world != null
            && Minecraft.getMinecraft().world.isRemote) {
            while (!actionQueue.isEmpty() && ticks == actionQueue.peek().tick) {
                actionQueue.remove().execute();
            }
            ++ticks;
        }
    }

    public static void scheduleTask(int tickTime, Runnable action) {
        long executeTick = ticks + tickTime;
        actionQueue.add(new ActionEntry(executeTick, action));
    }

    public static void scheduleCountdown(int startTick, int tickStep, int stopTick, IAction action) {
        int currentTick = startTick;
        while (currentTick < stopTick) {
            int secondsLeft = (stopTick - currentTick) / 20;
            scheduleTask(currentTick, () -> action.run(secondsLeft));
            currentTick += tickStep;
        }
    }

    public interface IAction {
        void run(Object param);
    }

    private static class ActionEntry implements Comparable {

        private final Runnable action;
        private final Long tick;

        public ActionEntry(Long tick, Runnable action) {
            this.tick = tick;
            this.action = action;
        }

        public void execute() {
            action.run();
        }

        @Override
        public int compareTo(Object o) {
            ActionEntry entry = (ActionEntry) o;
            if (entry.tick == this.tick) return 0;
            return entry.tick > this.tick ? -1 : 1;
        }
    }


}
