package com.commodorethrawn.revivemod.common.network;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.network.title.AbstractMessageTitle;
import com.commodorethrawn.revivemod.common.network.title.MessageEliminated;
import com.commodorethrawn.revivemod.common.network.title.MessageFightEnd;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class PacketHandler {
    public static final SimpleNetworkWrapper INSTANCE = new SimpleNetworkWrapper(ReviveMod.MODID);

    public static void registerPackets(Side side) {
        int id = 0;
        INSTANCE.registerMessage(MessageFightEnd.MessageHandler.class, MessageFightEnd.class, ++id, side);
        INSTANCE.registerMessage(MessageEliminated.MessageHandler.class, MessageEliminated.class, ++id, side);
        INSTANCE.registerMessage(MessageFireworkBall.MessageHandler.class, MessageFireworkBall.class, ++id, side);
        INSTANCE.registerMessage(MessageLookDir.MessageHandler.class, MessageLookDir.class, ++id, side);
        INSTANCE.registerMessage(MessageAltar.MessageHandler.class, MessageAltar.class, ++id, side);
        INSTANCE.registerMessage(AbstractMessageTitle.Basic.Handler.class, AbstractMessageTitle.Basic.class, ++id, side);
    }
}
