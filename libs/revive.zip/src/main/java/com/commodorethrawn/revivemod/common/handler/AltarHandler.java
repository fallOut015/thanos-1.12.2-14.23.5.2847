package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import com.commodorethrawn.revivemod.common.item.ItemHandler;
import com.commodorethrawn.revivemod.common.network.*;
import com.commodorethrawn.revivemod.common.network.title.AbstractMessageTitle;
import com.commodorethrawn.revivemod.common.storage.StorageHandler;
import com.commodorethrawn.revivemod.common.util.ActionScheduler;
import com.commodorethrawn.revivemod.common.util.CommonHelper;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

import java.util.List;
import java.util.Random;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class AltarHandler {

    public static BlockPos skullPos = new BlockPos(ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ);
    public static boolean showStar = false;

    @SubscribeEvent
    public static void logIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!event.player.world.isRemote) {
            System.out.println("SENDING MESSAGE");
            PacketHandler.INSTANCE.sendTo(new MessageAltar(skullPos.getX(), skullPos.getY(), skullPos.getZ(), AltarHandler.showStar, AltarHandler.isReviving), (EntityPlayerMP) event.player);
        }
    }

    @SubscribeEvent
    public static void skullPlace(BlockEvent.EntityPlaceEvent event) {
        if (!event.getWorld().isRemote && event.getEntity() instanceof EntityPlayerMP) {
            if (event.getWorld().getTileEntity(event.getPos()) instanceof TileEntitySkull) {
                TileEntitySkull te = (TileEntitySkull) event.getWorld().getTileEntity(event.getPos());
                if (te.getSkullType() == 1 && event.getPos().equals(skullPos)) {
                    if (checkAltar(event.getWorld())) {
                        convertAltar(event.getWorld());
                        ActionScheduler.scheduleTask(18000, () -> {
                            AltarHandler.showStar = false;
                            PacketHandler.INSTANCE.sendToAll(new MessageAltar(ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ, false, false));
                        });
                    }
                }
            }
        }
    }

    private static boolean summoning = false;
    @SubscribeEvent
    public static void summonPlayer(ItemTossEvent event) {
        if (!event.getEntity().world.isRemote
                && CommonHelper.isInPair(event.getPlayer().getUniqueID())
                && showStar) {
            ItemStack tossedItem = event.getEntityItem().getItem();
            if (tossedItem.getItem() != ItemHandler.totemResurrection && tossedItem.getItem() != Items.SKULL && tossedItem.getMetadata() != 3) {
                return;
            }
            World world = event.getEntity().getEntityWorld();
            UUID pairId = CommonHelper.getPair(event.getPlayer().getUniqueID());
            EntityPlayerMP pairPlayer = FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerByUUID(pairId);
            if (pairPlayer == null) {
                return;
            }
            ActionScheduler.scheduleTask(40, () -> {
                if (!summoning) {
                    List<EntityItem> itemList = world.getEntitiesWithinAABB(EntityItem.class, new AxisAlignedBB(skullPos.add(0, -1, 0)).grow(3.5F));
                    EntityItem skull = null;
                    EntityItem totem = null;
                    if (tossedItem.getItem() == Items.SKULL && tossedItem.getMetadata() == 3) {
                        skull = event.getEntityItem();
                        for (EntityItem item : itemList) {
                            if (item.getItem().getItem() == ItemHandler.totemResurrection) {
                                totem = item;
                                break;
                            }
                        }
                    } else {
                        totem = event.getEntityItem();
                        for (EntityItem item : itemList) {
                            if (item.getItem().getItem() == Items.SKULL && item.getItem().getMetadata() == 3) {
                                skull = item;
                                break;
                            }
                        }
                    }
                    if (totem != null && skull != null) {
                        System.out.println("Found totem and skull");
                        summoning = true;
                        revive(world, pairPlayer, skull, totem);
                    }
                }
            });
        }
    }

    public static boolean isReviving = false;
    private static void revive(World world, EntityPlayerMP playerMP, EntityItem skull, EntityItem totem) {
        if (playerMP != null) {
            itemAnimation(world, skull, totem);
            doRevive(world, playerMP);
        }
    }

    private static void itemAnimation(World world, EntityItem skull, EntityItem totem) {
        totem.setInfinitePickupDelay();
        skull.setInfinitePickupDelay();
        PacketHandler.INSTANCE.sendToAll(new MessageAltar(ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ, true, true));
        int tickDelay = 20;
        ActionScheduler.scheduleTask(tickDelay, () -> {
            EntityLightningBolt lightning = new EntityLightningBolt(world, skull.posX, skull.posY - 1, skull.posZ, true);
            world.addWeatherEffect(lightning);
            skull.setDead();
        });
        tickDelay += 20;
        ActionScheduler.scheduleTask(tickDelay, () -> {
            EntityLightningBolt lightning = new EntityLightningBolt(world, totem.posX, totem.posY - 1, totem.posZ, true);
            world.addWeatherEffect(lightning);
            totem.setDead();
        });
        Random rand = new Random();
        for (tickDelay += 20; tickDelay <= 100; tickDelay += 10) {
            ActionScheduler.scheduleTask(tickDelay, () -> {
                int offX = rand.nextInt(7) - 3;
                int offZ = rand.nextInt(7) - 3;
                EntityLightningBolt bolt = new EntityLightningBolt(world, totem.posX + offX, totem.posY - 1, totem.posZ + offZ, true);
                world.addWeatherEffect(bolt);
            });
        }
    }

    public static void doRevive(World world, EntityPlayerMP playerMP) {
        int tickDelay = 110;
        ActionScheduler.scheduleTask(tickDelay + 10, () -> {
            world.playSound(null, ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ, SoundEvents.ENTITY_GHAST_HURT, SoundCategory.RECORDS, 10.0F, 0.5F);
        });
        ActionScheduler.scheduleTask(tickDelay + 15, () -> {
            PacketHandler.INSTANCE.sendToAll(new AbstractMessageTitle.Basic("revivemod.revive", "revivemod.subrevive", 0.0F, 1.0F, 1.0F, 30, 240, playerMP.getName()));
            playerMP.setPositionAndUpdate(skullPos.getX() + 0.5, skullPos.getY() - 1, skullPos.getZ() + 0.5);
            playerMP.setGameType(GameType.SURVIVAL);
            playerMP.getEntityData().removeTag("isDead");
            PacketHandler.INSTANCE.sendTo(new MessageLookDir(90.0F, 0), playerMP);
            world.createExplosion(playerMP, skullPos.getX(), skullPos.getY() - 1, skullPos.getZ(), 2.0F, false);
            StorageHandler.removeGrave(playerMP.getUniqueID());
        });
        ActionScheduler.scheduleTask(tickDelay + 35, () -> {
            showStar = false;
            summoning = false;
            PacketHandler.INSTANCE.sendToAll(new MessageAltar(ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ, false, false));
        });
    }

    private static boolean checkAltar(World world) {
        ResourceLocation candle = new ResourceLocation("thebetweenlands", "mud_flower_pot_candle");
        return world.getBlockState(skullPos.add(0, -1, 0)).getBlock() == Blocks.EMERALD_BLOCK
                && world.getBlockState(skullPos.add(1, -1, 0)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(skullPos.add(-1, -1, 0)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(skullPos.add(0, -1, 1)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(skullPos.add(0, -1, -1)).getBlock() == Blocks.GOLD_BLOCK
                && world.getBlockState(skullPos.add(1, -1, 1)).getBlock().getRegistryName().equals(candle)
                && world.getBlockState(skullPos.add(1, -1, -1)).getBlock().getRegistryName().equals(candle)
                && world.getBlockState(skullPos.add(-1, -1, 1)).getBlock().getRegistryName().equals(candle)
                && world.getBlockState(skullPos.add(-1, -1, -1)).getBlock().getRegistryName().equals(candle)
                && world.getBlockState(skullPos.add(0, -2, 0)).getBlock() == Blocks.DIAMOND_BLOCK
                && world.getBlockState(skullPos.add(1, -2, 0)).getBlock() == Blocks.EMERALD_BLOCK
                && world.getBlockState(skullPos.add(-1, -2, 0)).getBlock() == Blocks.EMERALD_BLOCK
                && world.getBlockState(skullPos.add(0, -2, 1)).getBlock() == Blocks.EMERALD_BLOCK
                && world.getBlockState(skullPos.add(0, -2, -1)).getBlock() == Blocks.EMERALD_BLOCK
                && world.getBlockState(skullPos.add(1, -2, 1)).getBlock() == Blocks.DIAMOND_BLOCK
                && world.getBlockState(skullPos.add(1, -2, -1)).getBlock() == Blocks.DIAMOND_BLOCK
                && world.getBlockState(skullPos.add(-1, -2, 1)).getBlock() == Blocks.DIAMOND_BLOCK
                && world.getBlockState(skullPos.add(-1, -2, -1)).getBlock() == Blocks.DIAMOND_BLOCK;
    }

    private static void convertAltar(World world) {
        ActionScheduler.scheduleTask(10, () -> {
            EntityLightningBolt bolt = new EntityLightningBolt(world, skullPos.getX() - 0.5, skullPos.getY() - 1, skullPos.getZ() - 0.5, true);
            world.addWeatherEffect(bolt);
            world.setBlockState(skullPos.add(-1, -1, -1), Blocks.FIRE.getDefaultState());
            world.setBlockState(skullPos.add(-1, -2, -1), Blocks.NETHERRACK.getDefaultState());
        });
        ActionScheduler.scheduleTask(30, () -> {
            EntityLightningBolt bolt = new EntityLightningBolt(world, skullPos.getX() - 0.5, skullPos.getY() - 1, skullPos.getZ() + 1.5, true);
            world.addWeatherEffect(bolt);
            world.setBlockState(skullPos.add(-1, -1, 1), Blocks.FIRE.getDefaultState());
            world.setBlockState(skullPos.add(-1, -2, 1), Blocks.NETHERRACK.getDefaultState());
        });
        ActionScheduler.scheduleTask(50, () -> {
            EntityLightningBolt bolt = new EntityLightningBolt(world, skullPos.getX() + 1.5, skullPos.getY() - 1, skullPos.getZ() + 1.5, true);
            world.addWeatherEffect(bolt);
            world.setBlockState(skullPos.add(1, -1, 1), Blocks.FIRE.getDefaultState());
            world.setBlockState(skullPos.add(1, -2, 1), Blocks.NETHERRACK.getDefaultState());
        });
        ActionScheduler.scheduleTask(70, () -> {
            EntityLightningBolt bolt = new EntityLightningBolt(world, skullPos.getX() + 1.5, skullPos.getY() - 1, skullPos.getZ() - 0.5, true);
            world.addWeatherEffect(bolt);
            world.setBlockState(skullPos.add(1, -1, -1), Blocks.FIRE.getDefaultState());
            world.setBlockState(skullPos.add(1, -2, -1), Blocks.NETHERRACK.getDefaultState());
        });
        ActionScheduler.scheduleTask(90, () -> {
            for (int tickDelay = 0; tickDelay <= 9; tickDelay += 3) {
                ActionScheduler.scheduleTask(tickDelay, () -> {
                    EntityLightningBolt bolt = new EntityLightningBolt(world, skullPos.getX() + 0.5, skullPos.getY(), skullPos.getZ() + 0.5, true);
                    world.addWeatherEffect(bolt);
                });
            }
            ActionScheduler.scheduleTask(18, () -> {
                world.playSound(null, skullPos, SoundEvents.ENTITY_ENDERMEN_SCREAM, SoundCategory.RECORDS, 2.0F, 1.0F);
                world.playSound(null, skullPos, SoundEvents.ENTITY_GHAST_SHOOT, SoundCategory.RECORDS, 2.0F, 1.0F);
                world.playSound(null, skullPos, SoundEvents.ENTITY_WITHER_SKELETON_HURT, SoundCategory.RECORDS, 2.0F, 1.0F);
                world.destroyBlock(skullPos, false);
                for (int x = -1; x <= 1; ++x) {
                    for (int y = -2; y <= -1; ++y) {
                        for (int z = -1; z <= 1; ++z) {
                            world.destroyBlock(skullPos.add(x, y, z), false);
                        }
                    }
                }
                ActionScheduler.scheduleTask(18, () -> {
                    showStar = true;
                    PacketHandler.INSTANCE.sendToAll(new MessageAltar(ReviveConfig.altarSkullX, ReviveConfig.altarSkullY, ReviveConfig.altarSkullZ, true, false));
                });
            });
        });
    }
}
