package com.commodorethrawn.revivemod.common.config;

import com.commodorethrawn.revivemod.ReviveMod;
import net.minecraftforge.common.config.Config;

@Config(modid = ReviveMod.MODID, type = Config.Type.INSTANCE)
public class ReviveConfig {
    @Config.Comment("Set player teleport position in arena")
    public static int teleportX = 40;
    public static int teleportY = 52;
    public static int teleportZ = 40;

    @Config.Comment("Set time before arena mob spawns (in ticks)")
    public static int delayTicks = 600;

    @Config.Comment("Set the mob for the boss")
    public static String bossMob = "minecraft:zombie";

    @Config.Comment("Set the center position for the arena. Also where the boss will spawn")
    public static int bossX = 40;
    public static int bossY = 52;
    public static int bossZ = 40;

    @Config.Comment("Bottom North-West Corner of arena")
    public static int cornerX = 30;
    public static int cornerY = 40;
    public static int cornerZ = 30;

    @Config.Comment("Position of wither skull for altar")
    public static int altarSkullX = 10;
    public static int altarSkullY = 15;
    public static int altarSkullZ =  10;
}
