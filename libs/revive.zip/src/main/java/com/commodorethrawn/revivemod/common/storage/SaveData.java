package com.commodorethrawn.revivemod.common.storage;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.handler.AltarHandler;
import com.commodorethrawn.revivemod.common.handler.FightStartHandler;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.common.util.Constants;

import java.util.UUID;

public class SaveData extends WorldSavedData {

    public SaveData(String name) {
        super(name);
    }

    public SaveData() {
        super(ReviveMod.MODID);
        markDirty();
    }

    public static SaveData get(World world) {
        MapStorage storage = world.getMapStorage();
        assert storage != null;
        SaveData data = (SaveData) storage.getOrLoadData(SaveData.class, ReviveMod.MODID);
        if (data == null) {
            data = new SaveData();
            world.setData(ReviveMod.MODID, data);
        }
        return data;
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        StorageHandler.clearData();
        AltarHandler.showStar = nbt.getBoolean("showStar");
        FightStartHandler.inFight = nbt.getBoolean("inFight");
        for (NBTBase compound : nbt.getTagList("graveList", Constants.NBT.TAG_COMPOUND)) {
            NBTTagCompound graveTag = (NBTTagCompound) compound;
            BlockPos gravePos = new BlockPos(graveTag.getInteger("posX"), graveTag.getInteger("posY"), graveTag.getInteger("posZ"));
            UUID playerId = graveTag.getUniqueId("playerId");
            boolean enabled = graveTag.getBoolean("enabled");
            StorageHandler.addGrave(playerId, gravePos, enabled);
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagList graveListTag = new NBTTagList();
        for (UUID playerId : StorageHandler.getGraveIds()) {
            NBTTagCompound graveTag = new NBTTagCompound();
            graveTag.setUniqueId("playerId", playerId);
            BlockPos gravePos = StorageHandler.getGravePos(playerId);
            boolean enabled = StorageHandler.isGraveEnabled(gravePos);
            graveTag.setInteger("posX", gravePos.getX());
            graveTag.setInteger("posY", gravePos.getY());
            graveTag.setInteger("posZ", gravePos.getZ());
            graveTag.setBoolean("enabled", enabled);
            graveListTag.appendTag(graveTag);
        }
        compound.setBoolean("showStar", AltarHandler.showStar);
        compound.setTag("graveList", graveListTag);
        compound.setBoolean("inFight", FightStartHandler.inFight);
        return compound;
    }
}
