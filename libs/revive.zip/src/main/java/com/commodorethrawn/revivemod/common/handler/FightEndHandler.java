package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import com.commodorethrawn.revivemod.common.item.ItemHandler;
import com.commodorethrawn.revivemod.common.network.title.MessageEliminated;
import com.commodorethrawn.revivemod.common.network.title.MessageFightEnd;
import com.commodorethrawn.revivemod.common.network.MessageFireworkBall;
import com.commodorethrawn.revivemod.common.network.PacketHandler;
import com.commodorethrawn.revivemod.common.util.ActionScheduler;
import com.commodorethrawn.revivemod.common.util.CommonHelper;
import com.daposeidonguy.teamsmod.common.storage.StorageHelper;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.forge.ForgeWorldEdit;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.util.io.Closer;
import com.sk89q.worldedit.world.registry.WorldData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.io.InputStream;
import java.util.List;
import java.util.Random;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class FightEndHandler {

    @SubscribeEvent
    public static void bossDeath(LivingDropsEvent event) {
        if (!event.getEntity().world.isRemote && event.getEntityLiving().getEntityData().hasKey("isBoss")) {
            ItemStack stackTotem = new ItemStack(ItemHandler.totemResurrection);
            EntityItem dropTotem = new EntityItem(
                    event.getEntity().getEntityWorld(),
                    event.getEntity().posX,
                    event.getEntity().posY,
                    event.getEntity().posZ, stackTotem);
            event.getDrops().add(dropTotem);
            EntityPlayerMP killer = null;
            if (event.getSource().getTrueSource() instanceof EntityPlayerMP) {
                killer = (EntityPlayerMP) event.getSource().getTrueSource();
            } else {
                for (EntityPlayer player : event.getEntityLiving().world.playerEntities) {
                    if (player.getEntityData().hasKey("isFighter")) {
                        killer = (EntityPlayerMP) player;
                    }
                }
            }
            EntityLivingBase boss = event.getEntityLiving();
            playWinEffects(event.getEntityLiving().getEntityWorld(), boss.posX, boss.posY, boss.posZ);
            fightEnd(true, killer);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void playerDeath(LivingDeathEvent event) {
        if (!event.getEntityLiving().world.isRemote && event.getEntityLiving().getEntityData().hasKey("isFighter")) {
            event.getEntityLiving().getEntityData().removeTag("isFighter");
            Entity source = event.getSource().getTrueSource();
            EntityPlayerMP playerMP = (EntityPlayerMP) event.getEntityLiving();
            if (source != null) {
                event.getSource().getTrueSource().getEntityData().removeTag("isBoss");
                event.getSource().getTrueSource().setDead();
            } else {
                Class bossClass = EntityList.getClass(new ResourceLocation(ReviveConfig.bossMob));
                List<Entity> entityList = event.getEntity().getEntityWorld().getEntitiesWithinAABB(bossClass, new AxisAlignedBB(playerMP.getPosition()).grow(100, 100, 100));
                for (Entity entity : entityList) {
                    if (entity.getEntityData().hasKey("isBoss")) {
                        entity.getEntityData().removeTag("isBoss");
                        entity.setDead();
                        break;
                    }
                }
            }
            playLoseEffects(playerMP.getEntityWorld(), playerMP.posX, playerMP.posY, playerMP.posZ);
            fightEnd(false, (EntityPlayerMP) event.getEntityLiving());
            PacketHandler.INSTANCE.sendToAll(new MessageEliminated(StorageHelper.getTeam(event.getEntityLiving().getUniqueID())));
        }
    }

    private static void fightEnd(boolean won, EntityPlayerMP playerMP) {
        if (!CommonHelper.isInPair(playerMP.getUniqueID())) {
            return;
        }
        PacketHandler.INSTANCE.sendToAll(new MessageFightEnd(won, playerMP.getName()));
        if (FightStartHandler.bossInfo != null) {
            FightStartHandler.bossInfo.setVisible(false);
            FightStartHandler.bossInfo = null;
        }
        FightStartHandler.inFight = false;
        ActionScheduler.scheduleTask(300, () -> {
            List<EntityPlayerMP> playerList = playerMP.getEntityWorld().getEntitiesWithinAABB(EntityPlayerMP.class, new AxisAlignedBB(playerMP.getPosition()).grow(100, 100, 100), p -> p.getEntityData().hasKey("oldPos"));
            for (EntityPlayerMP player : playerList) {
                player.sendMessage(new TextComponentTranslation("revivemod.returning"));
                BlockPos oldPos = NBTUtil.getPosFromTag(player.getEntityData().getCompoundTag("oldPos"));
                player.setPositionAndUpdate(oldPos.getX(), oldPos.getY() + 1.5F, oldPos.getZ());
                if (player == playerMP) {
                    EntityPlayer teammate = player.getEntityWorld().getPlayerEntityByUUID(CommonHelper.getPair(player.getUniqueID()));
                    if (teammate != null) {
                        teammate.setPositionAndUpdate(oldPos.getX(), oldPos.getY() + 2, oldPos.getZ());
                    }
                } else {
                    GameType oldType = GameType.getByID(player.getEntityData().getInteger("oldGamemode"));
                    player.setGameType(oldType);
                }
                player.getEntityData().removeTag("oldPos");
                player.getEntityData().removeTag("oldGamemode");
            }
            buildArena();
        });
    }

    public static void buildArena() {
        World world = FMLCommonHandler.instance().getMinecraftServerInstance().getEntityWorld();
        try {
            InputStream streamArena = ReviveMod.class.getResourceAsStream("/assets/revivemod/schematics/arena.schematic");
            ClipboardReader reader = ClipboardFormat.SCHEMATIC.getReader(Closer.create().register(streamArena));
            WorldData data = ForgeWorldEdit.inst.getWorld(world).getWorldData();
            Clipboard clipboard = reader.read(data);
            ClipboardHolder holder = new ClipboardHolder(clipboard, data);
            streamArena.close();
            Vector to = new Vector(ReviveConfig.cornerX, ReviveConfig.cornerY, ReviveConfig.cornerZ);
            Operation operation = holder.createPaste(WorldEdit.getInstance().getEditSessionFactory().getEditSession(ForgeWorldEdit.inst.getWorld(world), 1000000000), data).to(to).ignoreAirBlocks(false).build();
            Operations.completeLegacy(operation);
        } catch (Exception var8) {
            var8.printStackTrace();
        }
    }

    private static void playWinEffects(World world, double x, double y, double z) {
        world.playSound(null, new BlockPos(x, y, z), SoundEvents.ENTITY_WITHER_DEATH, SoundCategory.RECORDS, 20.0F, 0.5F);
        Random rand = new Random();
        int timerOffset = 10;
        for (int i = 0; i < 8; ++i) {
            ActionScheduler.scheduleTask(timerOffset, () -> {
                int offsetX = rand.nextInt(7) - 3;
                int offsetZ = rand.nextInt(7) - 3;
                EntityLightningBolt bolt = new EntityLightningBolt(world, x + offsetX, y - 1, z + offsetZ, true);
                world.addWeatherEffect(bolt);
            });
            timerOffset += rand.nextInt(11);
        }
        ItemStack fireworkStack = new ItemStack(Items.FIREWORKS);
        fireworkStack.setTagCompound(buildFirework());
        ActionScheduler.scheduleCountdown(timerOffset, 30, timerOffset + 120, seconds -> {
            EntityFireworkRocket firework1 = new EntityFireworkRocket(world, x - rand.nextInt(11), y, z - rand.nextInt(11), fireworkStack);
            EntityFireworkRocket firework2 = new EntityFireworkRocket(world, x - rand.nextInt(11), y, z + rand.nextInt(11), fireworkStack);
            EntityFireworkRocket firework3 = new EntityFireworkRocket(world, x + rand.nextInt(11), y, z - rand.nextInt(11), fireworkStack);
            EntityFireworkRocket firework4 = new EntityFireworkRocket(world, x + rand.nextInt(11), y, z + rand.nextInt(11), fireworkStack);
            world.spawnEntity(firework1);
            world.spawnEntity(firework2);
            world.spawnEntity(firework3);
            world.spawnEntity(firework4);
        });
        ActionScheduler.scheduleTask(timerOffset + 10, () -> {
            PacketHandler.INSTANCE.sendToAll(new MessageFireworkBall(x, y + 2, z));
            world.setWorldTime(12000);
            world.getWorldInfo().setThundering(false);
            world.getWorldInfo().setRaining(false);
        });
    }

    private static NBTTagCompound buildFirework() {
        NBTTagCompound fireworksTag = new NBTTagCompound();
        NBTTagCompound fireworkTag = new NBTTagCompound();
        fireworkTag.setInteger("Flight", 1);
        NBTTagList explosionsTag = new NBTTagList();
        NBTTagCompound explosionTag = new NBTTagCompound();
        explosionTag.setInteger("Type", 1);
        explosionTag.setInteger("Flicker", 1);
        explosionTag.setInteger("Trail", 1);
        int[] fadeColors = new int[]{1973019,4408131};
        int[] explosionColors = new int[]{4408131,11743532};
        explosionTag.setIntArray("Colors", explosionColors);
        explosionTag.setIntArray("FadeColors", fadeColors);
        explosionsTag.appendTag(explosionTag);
        fireworkTag.setTag("Explosions", explosionsTag);
        fireworksTag.setTag("Fireworks", fireworkTag);
        return fireworksTag;
    }

    private static void playLoseEffects(World world, double x, double y, double z) {
        Random rand = new Random();
        int timerOffset = 10;
        for (int i = 0; i < 8; ++i) {
            ActionScheduler.scheduleTask(timerOffset, () -> {
                int offsetX = rand.nextInt(7) - 3;
                int offsetZ = rand.nextInt(7) - 3;
                EntityLightningBolt bolt = new EntityLightningBolt(world, x + offsetX, y - 1, z + offsetZ, true);
                world.addWeatherEffect(bolt);
            });
            timerOffset += rand.nextInt(11);
        }
        ActionScheduler.scheduleTask(timerOffset, () -> {
            world.createExplosion(null, x, y, z, 5.0F, true);
            world.getWorldInfo().setRaining(true);
            world.getWorldInfo().setThundering(true);
            world.setWorldTime(18000);
        });
    }
}
