package com.commodorethrawn.revivemod.common.util;

import com.daposeidonguy.teamsmod.common.storage.StorageHelper;

import java.util.List;
import java.util.UUID;

public class CommonHelper {
    public static boolean isInPair(UUID playerId) {
        String playerTeam = StorageHelper.getTeam(playerId);
        if (playerTeam == null) return false;
        return StorageHelper.getTeamPlayers(playerTeam).size() == 2;
    }
    /* Requires isInPair(playerId) to be true */
    public static boolean isSamePair(UUID player1, UUID player2) {
        return StorageHelper.getTeam(player1).equals(StorageHelper.getTeam(player2));
    }
    /* Requires isInPair(playerId) to be true */
    public static UUID getPair(UUID playerId) {
        String team = StorageHelper.getTeam(playerId);
        List<UUID> players = StorageHelper.getTeamPlayers(team);
        return players.get(0).equals(playerId) ? players.get(1) : players.get(0);
    }
}
