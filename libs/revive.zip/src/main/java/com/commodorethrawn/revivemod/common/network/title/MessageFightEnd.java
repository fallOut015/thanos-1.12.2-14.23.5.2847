package com.commodorethrawn.revivemod.common.network.title;

import com.commodorethrawn.revivemod.client.util.TitleHelper;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageFightEnd extends AbstractMessageTitle {

    public MessageFightEnd() {
    }

    public MessageFightEnd(boolean won, String fighter) {
        super("revivemod.fightend", getSubtitle(won), getColors(won), 30, 240, fighter);
    }

    public static String getSubtitle(boolean won) {
        if (won) {
            return "revivemod.subfightwon";
        }
        return "revivemod.subfightlost";
    }

    public static float[] getColors(boolean won) {
        if (won) {
            return new float[]{0.0F, 1.0F, 0.5F};
        }
        return new float[]{0.7F, 0.0F, 0.2F};
    }

    public static class MessageHandler implements IMessageHandler<MessageFightEnd, IMessage> {

        @Override
        public IMessage onMessage(MessageFightEnd message, MessageContext ctx) {
            TitleHelper.clearTitles();
            return MessageFightEnd.onMessage(message);
        }
    }
}
