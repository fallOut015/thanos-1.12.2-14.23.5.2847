package com.commodorethrawn.revivemod.common.handler;

import com.commodorethrawn.revivemod.ReviveMod;
import com.commodorethrawn.revivemod.common.config.ReviveConfig;
import com.commodorethrawn.revivemod.common.network.title.AbstractMessageTitle;
import com.commodorethrawn.revivemod.common.network.MessageLookDir;
import com.commodorethrawn.revivemod.common.network.PacketHandler;
import com.commodorethrawn.revivemod.common.storage.StorageHandler;
import com.commodorethrawn.revivemod.common.util.ActionScheduler;
import com.commodorethrawn.revivemod.common.util.CommonHelper;
import com.daposeidonguy.teamsmod.common.storage.StorageHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.world.BossInfo;
import net.minecraft.world.BossInfoServer;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = ReviveMod.MODID)
public class FightStartHandler {

    public static boolean inFight = false;
    public static BossInfoServer bossInfo;
    public static List<EntityPlayerMP> spectatingPlayers = new ArrayList<>();

    public static void addSpectator(EntityPlayerMP playerMP) {
        spectatingPlayers.add(playerMP);
    }

    @SubscribeEvent
    public static void breakGrave(BlockEvent.BreakEvent event) {
        if (!event.getPlayer().getEntityWorld().isRemote && event.getState().getBlock() == Blocks.WALL_SIGN) {
            StorageHandler.removeGrave(event.getPos());
        }
    }

    @SubscribeEvent
    public static void clickGrave(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getWorld().isRemote
                && event.getWorld().getBlockState(event.getPos()).getBlock() == Blocks.WALL_SIGN) {
            if (CommonHelper.isInPair(event.getEntityPlayer().getUniqueID())
                    && StorageHandler.getGraveId(event.getPos()) != null
                    && StorageHandler.isGraveEnabled(event.getPos())
                    && !inFight) {
                EntityPlayerMP fighter = (EntityPlayerMP) event.getEntityPlayer();
                UUID deadId = StorageHandler.getGraveId(event.getPos());
                if (CommonHelper.isSamePair(fighter.getUniqueID(), deadId)) {
                    fighter.getEntityData().setTag("oldPos", NBTUtil.createPosTag(event.getPos()));
                    fighter.getEntityData().setInteger("oldGamemode", fighter.interactionManager.getGameType().getID());
                    fighter.getEntityData().setBoolean("isFighter", true);
                    fighter.setPositionAndUpdate(ReviveConfig.teleportX, ReviveConfig.teleportY, ReviveConfig.teleportZ);
                    PacketHandler.INSTANCE.sendTo(new MessageLookDir(-90.0F, 0.0F), fighter);
                    EntityPlayerMP dead = FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerByUUID(deadId);
                    startFight(fighter, dead);
                    StorageHandler.disableGrave(event.getPos());
                } else { //If different team
                    fighter.sendMessage(new TextComponentTranslation("revivemod.notsameteam"));
                }
            } else if (StorageHandler.getGraveId(event.getPos()) != null && StorageHandler.isGraveEnabled(event.getPos())) {
                if (inFight) {
                    event.getEntityPlayer().sendMessage(new TextComponentTranslation("revivemod.fightinprogress"));
                } else {
                    event.getEntityPlayer().sendMessage(new TextComponentTranslation("revivemod.notsameteam"));
                }
            }
        }
    }

    private static void startFight(EntityPlayerMP fighter, EntityPlayerMP dead) {
        inFight = true;
        PacketHandler.INSTANCE.sendToAll(new AbstractMessageTitle.Basic("revivemod.fightstart", "revivemod.subfightstart", 0.86F, 0.08F, 0.23F, 30, 240, fighter.getDisplayNameString()));
        if (dead != null) {
            dead.setPositionAndUpdate(ReviveConfig.teleportX, ReviveConfig.teleportY + 2, ReviveConfig.teleportZ);
            PacketHandler.INSTANCE.sendTo(new MessageLookDir(-90.0F, 0.0F), dead);
        }
        ActionScheduler.scheduleCountdown(0, 100, ReviveConfig.delayTicks, seconds -> {
            if (FightStartHandler.inFight) {
                ITextComponent chat = new TextComponentTranslation("revivemod.countdown", seconds);
                chat.setStyle(new Style().setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/spectate")));
                FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().sendMessage(chat);
            }
        });
        ActionScheduler.scheduleCountdown(200, 100, ReviveConfig.delayTicks, seconds -> {
            if (FightStartHandler.inFight) {
                AbstractMessageTitle.Basic title = new AbstractMessageTitle.Basic("revivemod.fightstarting", "revivemod.subcountdown", 0.86F, 0.08F, 0.23F, 10, 180, String.valueOf(seconds));
                for (EntityPlayerMP playerMP : spectatingPlayers) {
                    PacketHandler.INSTANCE.sendTo(title, playerMP);
                }
                PacketHandler.INSTANCE.sendTo(title, fighter);
            }
        });
        ActionScheduler.scheduleTask(ReviveConfig.delayTicks, () -> {
            if (FightStartHandler.inFight) {
                ITextComponent chat = new TextComponentTranslation("revivemod.fightstarted", fighter.getDisplayNameString());
                chat.setStyle(new Style().setBold(true));
                FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().sendMessage(chat);
                World world = FMLCommonHandler.instance().getMinecraftServerInstance().getEntityWorld();
                spawnEffects(world);
                ActionScheduler.scheduleTask(260, () -> spawnBoss(world, fighter, dead));
            }
        });
    }

    private static void spawnBoss(World world, EntityPlayerMP fighter, EntityPlayerMP dead) {
        fighter.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 20, 3, false, false));
        world.createExplosion(null, ReviveConfig.bossX, ReviveConfig.bossY, ReviveConfig.bossZ, 2.5F, false);
        try {
            Class<? extends Entity> bossClass = EntityList.getClass(new ResourceLocation(ReviveConfig.bossMob));
            Constructor<? extends Entity> bossConstructor = bossClass.getConstructor(World.class);
            EntityLiving boss = (EntityLiving) bossConstructor.newInstance(world);
            boss.getEntityData().setBoolean("isBoss", true);
            boss.setPositionAndUpdate(ReviveConfig.bossX, ReviveConfig.bossY, ReviveConfig.bossZ);
            world.spawnEntity(boss);
            if (boss.isNonBoss()) {
                bossInfo = new BossInfoServer(boss.getDisplayName(), BossInfo.Color.PURPLE, BossInfo.Overlay.PROGRESS);
                bossInfo.addPlayer(fighter);
                if (dead != null) {
                    bossInfo.addPlayer(dead);
                }
                for (EntityPlayerMP player : spectatingPlayers) {
                    bossInfo.addPlayer(player);
                }
            }
            spectatingPlayers.clear();
        } catch (Exception ex) {
            ex.printStackTrace();
            FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().sendMessage(new TextComponentString("Bad boss name"));
            inFight = false;
        }
    }

    private static void spawnEffects(World world) {
        Random rand = new Random();
        int timerOffset = 0;
        for (int i = 0; i < 13; ++i) {
            timerOffset += 20;
            ActionScheduler.scheduleTask(timerOffset, () -> {
                int offsetX = rand.nextInt(27) - 14;
                int offsetZ = rand.nextInt(27) - 14;
                EntityLightningBolt bolt = new EntityLightningBolt(world, ReviveConfig.bossX + offsetX, ReviveConfig.bossY - 1, ReviveConfig.bossZ + offsetZ, true);
                world.addWeatherEffect(bolt);
            });
        }


    }

}
